# Axon 2.0 Alpha 2

## 更新
- 修复附件：Android 原生桥接支持 DOCX 文本提取、PDF 前 5 页转图片；保留图片、视频帧和文本文件上传。
- 注意：PDF/图片/视频帧需要 API 模型支持视觉输入；纯文本 DeepSeek 模型可能拒绝图片，不能误称已理解。
- 自动新对话：每次重新打开 App 自动切到新对话；如果当前对话本身为空则复用，历史对话保留。
- 界面优化：导航、输入栏、按钮、欢迎快捷提问、附件格式提示。
- 保留既有自定义 API、DeepSeek 搜索、Markdown、性格设置、上下文预算。

## 注意
- ZIP 是 Android 源码，不是 APK；未在 Android 真机编译测试。
- PDF 仅取前 5 页图片，不支持提取扫描件的可搜索文本；DOCX 仅提取正文文字，不保证表格、图片等完整保真。
- 目前不支持旧版 DOC、XLSX、PPTX 等格式。
- 使用原有 applicationId 和 localStorage key。安装更新需要相同签名，否则应先备份数据。
- 在 GitHub 仓库里替换同名 Axon-Android-With-Logo.zip 触发 Actions。


Alpha 2.2: Token 预算仅裁剪历史消息，不再删除当前消息的附件。

## Alpha 2.3 固定签名
- debug 和 release 均使用 app/axon-fixed-signing.jks 中的固定签名，GitHub Actions 继续执行 assembleDebug 即可；不用修改仓库的 build.yml。
- 包名保持 com.axon.app，versionCode=5，versionName=2.0.0-alpha2.3。
- **安全警告：** 为实现手机端一键替换 ZIP，签名私钥和密码包含在项目压缩包中。若上传到公开 GitHub 仓库，任何人都能获得私钥并伪造同签名 APK。这只适合个人测试，不适合公开发行。正式发布前应重新生成私钥并使用 GitHub Actions Secrets 私密存储，且此后始终备份原始私钥。
- 旧版不同签名 APK 无法覆盖安装，需要备份后卸载一次；以后使用同一密钥且 versionCode 递增即可覆盖升级。
