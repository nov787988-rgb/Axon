# Axon 2.0 Alpha 1

基于原 Axon Android WebView 项目迭代，保留原 applicationId 和 localStorage key，方便迁移现有设置。

## 本阶段已实现
- DeepSeek 官方 Chat Completions 的 thinking 开关；自定义 OpenAI 兼容 API 仍可用。
- 深度思考等级设置（含 max）。
- 可配置上下文近似预算（4k/12k/24k/48k），取代固定 24 条消息截断。
- 规范化 Chat Completions URL 拼接，拒绝误填 Responses 端点。
- 保留上一版本的 Markdown、Logo、性格、DeepSeek 搜索与附件处理。

## 尚未实现
自动摘要、严格 tokenizer、PDF/Word 解析、真正的模型工具调用循环、固定签名、云同步与 APK 实机测试。这是 alpha 阶段源码，不应称作完整 DeepSeek 功能对标版。

## GitHub Actions
将本 ZIP 重命名为 Axon-Android-With-Logo.zip 后替换仓库同名文件。仓库现有 workflow 需要已修复 setup-android 步骤。
