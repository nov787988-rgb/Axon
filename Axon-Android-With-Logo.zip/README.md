# Axon 2.0 Alpha 2

## 更新
- 修复附件：Android 原生桥接支持 DOCX 文本提取、PDF 前 5 页转图片；保留图片、视频帧和文本文件上传。
- 注意：PDF/图片/视频帧需要 API 模型支持视觉输入；纯文本 DeepSeek 模型可能拒绝图片，不能误称已理解。
- 自动新对话：每次重新打开 App 自动切到新对话；如果当前对话本身为空则复用，历史对话保留。
- 界面优化：导航、输入栏、按钮、欢迎快捷提问、附件格式提示。
- 保留既有自定义 API、DeepSeek 搜索、Markdown、性格设置、上下文预算。

## 注意
- ZIP 是 Android 源码，不是 APK；未在 Android 真机编译测试。
- PDF 仅取前 5 页图片，不支持提取扫描件的可搜索文本；DOCX 仅提取正文文字，不保证表格、图片等完整保真。
- 目前不支持旧版 DOC、XLSX、PPTX 等格式。
- 使用原有 applicationId 和 localStorage key。安装更新需要相同签名，否则应先备份数据。
- 在 GitHub 仓库里替换同名 Axon-Android-With-Logo.zip 触发 Actions。
