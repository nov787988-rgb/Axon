# Axon Android APK

这是 Axon 的安卓 WebView 封装版，内置现有 Axon 网页前端，使用真实的兼容 OpenAI API 聊天功能。它不是原生 Compose 重写版。

## 手机构建 APK
1. 在 GitHub 新建公开或私人仓库，例如 `Axon`。
2. 将本项目的所有文件及目录上传到仓库根目录（保留 `.github/workflows/build-apk.yml`）。
3. 打开仓库 Actions → Build Axon APK → Run workflow，或推送到 main 后自动触发。
4. 构建成功后，进入运行记录底部 Artifacts → Axon-APK，下载 ZIP 并解压，安装 `app-debug.apk`。

## 限制
- WebView 版本。图片识别需要视觉模型，网页搜索需要 Tavily Key，视频通过浏览器抽帧。
- 文件格式并非全部支持；PDF/Office/音频等尚未实现解析。
- API 端点需允许浏览器/WebView 的 CORS 请求；否则需可信服务端代理。
- 本地 API Key 存储于 WebView localStorage；请勿在共享设备保存敏感密钥。
- 此源码未在当前环境进行 Android 编译验证。
