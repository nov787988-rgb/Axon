package com.axon.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DocumentBridge {
    private final Context context;
    public DocumentBridge(Context context) { this.context = context.getApplicationContext(); }

    @JavascriptInterface
    public String parseDocument(String dataUrl, String filename) {
        try {
            int comma = dataUrl.indexOf(',');
            if (comma < 0) throw new IOException("无效的附件编码");
            byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
            if (bytes.length > 35 * 1024 * 1024) throw new IOException("文件超过 35MB 限制");
            String lower = filename == null ? "" : filename.toLowerCase(java.util.Locale.ROOT);
            if (lower.endsWith(".docx")) return parseDocx(bytes).toString();
            if (lower.endsWith(".pdf")) return parsePdf(bytes).toString();
            throw new IOException("仅支持 PDF 和 DOCX");
        } catch (Exception ex) {
            JSONObject result = new JSONObject();
            try { result.put("error", ex.getMessage() == null ? "解析失败" : ex.getMessage()); } catch (Exception ignored) {}
            return result.toString();
        }
    }

    private JSONObject parseDocx(byte[] bytes) throws Exception {
        String xml = null;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(entry.getName())) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = zip.read(buf)) != -1) {
                        if (out.size() + n > 5_000_000) throw new IOException("文档正文过大");
                        out.write(buf, 0, n);
                    }
                    xml = out.toString("UTF-8"); break;
                }
            }
        }
        if (xml == null) throw new IOException("DOCX 缺少正文文件");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        Document doc = factory.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        NodeList paragraphs = doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "p");
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < paragraphs.getLength() && text.length() < 100000; i++) {
            NodeList nodes = ((org.w3c.dom.Element) paragraphs.item(i)).getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "t");
            for (int j = 0; j < nodes.getLength(); j++) text.append(nodes.item(j).getTextContent());
            text.append('\n');
        }
        return new JSONObject().put("kind", "text").put("text", text.toString());
    }

    private JSONObject parsePdf(byte[] bytes) throws Exception {
        File file = File.createTempFile("axon_pdf_", ".pdf", context.getCacheDir());
        try {
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
            JSONArray pages = new JSONArray();
            try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(fd)) {
                int count = Math.min(5, renderer.getPageCount());
                for (int i = 0; i < count; i++) {
                    try (PdfRenderer.Page page = renderer.openPage(i)) {
                        float scale = Math.min(1.5f, 1200f / Math.max(page.getWidth(), page.getHeight()));
                        int w = Math.max(1, Math.round(page.getWidth() * scale));
                        int h = Math.max(1, Math.round(page.getHeight() * scale));
                        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        try {
                            bitmap.eraseColor(Color.WHITE);
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            ByteArrayOutputStream output = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output);
                            pages.put(new JSONObject().put("page", i + 1).put("data", "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)));
                        } finally { bitmap.recycle(); }
                    }
                }
                return new JSONObject().put("kind", "pdf").put("pages", pages).put("note", renderer.getPageCount() > count ? "仅提供前5页。" : "");
            }
        } finally { file.delete(); }
    }
}
