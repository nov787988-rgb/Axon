package com.axon.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DocumentBridge {
    private final Context context;
    public DocumentBridge(Context context) { this.context = context.getApplicationContext(); }

    @JavascriptInterface
    public String parseDocument(String dataUrl, String filename) {
        try {
            int comma = dataUrl.indexOf(',');
            if (comma < 0) throw new IOException("无效的附件编码");
            byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
            if (bytes.length > 35 * 1024 * 1024) throw new IOException("文件超过 35MB 限制");
            String lower = filename == null ? "" : filename.toLowerCase(java.util.Locale.ROOT);
            if (lower.endsWith(".docx")) return parseDocx(bytes).toString();
            if (lower.endsWith(".pdf")) return parsePdf(bytes).toString();
            if (lower.endsWith(".xlsx")) return parseXlsx(bytes).toString();
            if (lower.endsWith(".pptx")) return parsePptx(bytes).toString();
            throw new IOException("仅支持 PDF、DOCX、XLSX 和 PPTX");
        } catch (Exception ex) {
            JSONObject result = new JSONObject();
            try { result.put("error", ex.getMessage() == null ? "解析失败" : ex.getMessage()); } catch (Exception ignored) {}
            return result.toString();
        }
    }

    private JSONObject parseDocx(byte[] bytes) throws Exception {
        String xml = null;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(entry.getName())) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = zip.read(buf)) != -1) {
                        if (out.size() + n > 5_000_000) throw new IOException("文档正文过大");
                        out.write(buf, 0, n);
                    }
                    xml = out.toString("UTF-8"); break;
                }
            }
        }
        if (xml == null) throw new IOException("DOCX 缺少正文文件");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        Document doc = factory.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        NodeList paragraphs = doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "p");
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < paragraphs.getLength() && text.length() < 100000; i++) {
            NodeList nodes = ((org.w3c.dom.Element) paragraphs.item(i)).getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "t");
            for (int j = 0; j < nodes.getLength(); j++) text.append(nodes.item(j).getTextContent());
            text.append('\n');
        }
        return new JSONObject().put("kind", "text").put("text", text.toString());
    }

    private JSONObject parseXlsx(byte[] bytes) throws Exception {
        java.util.Map<String,String> entries = readOfficeXml(bytes);
        java.util.List<String> shared = new java.util.ArrayList<>();
        if (entries.containsKey("xl/sharedStrings.xml")) {
            Document d = parseXml(entries.get("xl/sharedStrings.xml"));
            NodeList items = d.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "si");
            for (int i=0;i<items.getLength();i++) {
                NodeList ts=((org.w3c.dom.Element)items.item(i)).getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","t");
                StringBuilder b=new StringBuilder(); for(int j=0;j<ts.getLength();j++) b.append(ts.item(j).getTextContent()); shared.add(b.toString());
            }
        }
        java.util.List<String> sheets=new java.util.ArrayList<>();
        for(String name:entries.keySet()) if(name.matches("xl/worksheets/sheet[0-9]+\\.xml")) sheets.add(name);
        java.util.Collections.sort(sheets);
        StringBuilder out=new StringBuilder();
        for(String sheet:sheets){
            Document d=parseXml(entries.get(sheet));
            NodeList rows=d.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","row");
            out.append("\n").append(sheet).append("\n");
            for(int i=0;i<rows.getLength()&&out.length()<180000;i++){
                NodeList cells=((org.w3c.dom.Element)rows.item(i)).getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","c");
                java.util.List<String> values=new java.util.ArrayList<>();
                for(int j=0;j<cells.getLength();j++){
                    org.w3c.dom.Element c=(org.w3c.dom.Element)cells.item(j); String ref=c.getAttribute("r"), type=c.getAttribute("t");
                    NodeList vs=c.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","v"); String v=vs.getLength()>0?vs.item(0).getTextContent():"";
                    if("s".equals(type)&&!v.isEmpty()){int index=Integer.parseInt(v);v=index>=0&&index<shared.size()?shared.get(index):v;}
                    if("inlineStr".equals(type)){NodeList ts=c.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","t");if(ts.getLength()>0)v=ts.item(0).getTextContent();}
                    values.add(ref+"="+v);
                }
                out.append(String.join(" | ",values)).append('\n');
            }
        }
        return new JSONObject().put("kind","text").put("text",out.toString());
    }

    private JSONObject parsePptx(byte[] bytes) throws Exception {
        java.util.Map<String,String> entries=readOfficeXml(bytes);
        java.util.List<String> slides=new java.util.ArrayList<>();
        for(String name:entries.keySet()) if(name.matches("ppt/slides/slide[0-9]+\\.xml")) slides.add(name);
        java.util.Collections.sort(slides); StringBuilder out=new StringBuilder();
        for(String slide:slides){
            Document d=parseXml(entries.get(slide));
            NodeList texts=d.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main","t");
            out.append("\n").append(slide).append("\n");
            for(int i=0;i<texts.getLength()&&out.length()<180000;i++) out.append(texts.item(i).getTextContent()).append('\n');
        }
        return new JSONObject().put("kind","text").put("text",out.toString());
    }

    private java.util.Map<String,String> readOfficeXml(byte[] bytes) throws Exception {
        java.util.Map<String,String> map=new java.util.TreeMap<>();
        try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;byte[] buf=new byte[8192];while((e=zip.getNextEntry())!=null){if(!e.isDirectory()&&e.getName().endsWith(".xml")&&(e.getName().startsWith("xl/")||e.getName().startsWith("ppt/"))){ByteArrayOutputStream out=new ByteArrayOutputStream();int n;while((n=zip.read(buf))!=-1){if(out.size()+n>8_000_000)throw new IOException("Office 文档 XML 过大");out.write(buf,0,n);}map.put(e.getName(),out.toString("UTF-8"));}}}
        return map;
    }

    private Document parseXml(String xml) throws Exception {
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);f.setFeature("http://xml.org/sax/features/external-general-entities",false);f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    private JSONObject parsePdf(byte[] bytes) throws Exception {
        File file = File.createTempFile("axon_pdf_", ".pdf", context.getCacheDir());
        try {
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
            JSONArray pages = new JSONArray();
            try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(fd)) {
                int count = Math.min(8, renderer.getPageCount());
                for (int i = 0; i < count; i++) {
                    try (PdfRenderer.Page page = renderer.openPage(i)) {
                        float scale = Math.min(1.5f, 1200f / Math.max(page.getWidth(), page.getHeight()));
                        int w = Math.max(1, Math.round(page.getWidth() * scale));
                        int h = Math.max(1, Math.round(page.getHeight() * scale));
                        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        try {
                            bitmap.eraseColor(Color.WHITE);
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            ByteArrayOutputStream output = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output);
                            pages.put(new JSONObject().put("page", i + 1).put("data", "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)));
                        } finally { bitmap.recycle(); }
                    }
                }
                return new JSONObject().put("kind", "pdf").put("pages", pages).put("note", renderer.getPageCount() > count ? "仅提供前8页。" : "");
            }
        } finally { file.delete(); }
    }
}
